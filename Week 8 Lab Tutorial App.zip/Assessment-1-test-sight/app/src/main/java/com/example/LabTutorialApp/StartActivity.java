package com.example.LabTutorialApp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.startRoot), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button button = findViewById(R.id.buttonUIEvent);
        button.setOnClickListener(view ->  {
                Intent intent = new Intent(StartActivity.this, MainActivity.class);
                intent.putExtra("message", "Hello World!");
                startActivity(intent);
        });

        Button button2 = findViewById(R.id.buttonUIEvent2);
        button2.setOnClickListener(view ->  {
                Intent intent = new Intent(StartActivity.this, LocationServicesActivity.class);
                startActivity(intent);
        });

        Button button3 = findViewById(R.id.FirebaseMLKit);
        button3.setOnClickListener(view ->  {
                Intent intent = new Intent(StartActivity.this, MLKitActivity.class);
                startActivity(intent);
        });

        Button button4 = findViewById(R.id.SQLiteButton);
        button4.setOnClickListener(view ->  {
                Intent intent = new Intent(StartActivity.this, SQLiteActivity.class);
                startActivity(intent);
        });

        Button button5 = findViewById(R.id.AnimationButton);
        button5.setOnClickListener(view -> {
            Intent intent = new Intent(StartActivity.this, AnimationActivity.class);
            startActivity(intent);
        });

        Button button6 = findViewById(R.id.MultimediaButton);
        button6.setOnClickListener(view -> {
            Intent intent = new Intent(StartActivity.this, MultimediaActivity.class);
            startActivity(intent);
        });

    }
}